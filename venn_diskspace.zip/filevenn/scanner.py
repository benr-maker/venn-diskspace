import os

def get_directory_tree(path):
    def get_size(start_path):
        total_size = 0
        total_files = 0
        for dirpath, _, filenames in os.walk(start_path):
            for f in filenames:
                fp = os.path.join(dirpath, f)
                try:
                    total_size += os.path.getsize(fp)
                    total_files += 1
                except Exception:
                    continue
        return total_size, total_files

    def build_node(directory):
        try:
            size, files = get_size(directory)
            children = []
            for entry in os.scandir(directory):
                if entry.is_dir(follow_symlinks=False):
                    children.append(build_node(entry.path))
            return {
                "name": os.path.basename(directory) or directory,
                "size": size,
                "files": files,
                "children": children
            }
        except PermissionError:
            return {"name": os.path.basename(directory), "size": 0, "files": 0, "children": []}

    return build_node(path)
