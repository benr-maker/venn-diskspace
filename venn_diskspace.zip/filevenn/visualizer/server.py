from flask import Flask, jsonify, render_template, request
import os
from filevenn.scanner import get_directory_tree

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/scan", methods=["POST"])
def scan():
    data = request.json
    path = data.get("path")
    if not path or not os.path.exists(path):
        return jsonify({"error": "Invalid path"}), 400
    return jsonify(get_directory_tree(path))

if __name__ == "__main__":
    app.run(debug=True)
